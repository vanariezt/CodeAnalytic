<!-- write script here -->
<?php

$config['sm_username'] = '';
$config['sm_password'] = '';
$config['sm_api_id'] = '';
$config['sm_api_key'] = '';
?>